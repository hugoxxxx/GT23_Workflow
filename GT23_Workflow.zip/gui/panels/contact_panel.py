# gui/panels/contact_panel.py
"""
EN: Contact Sheet panel for GUI (tkinter version)
CN: 底片索引 GUI 面板（tkinter版本）
"""

import os
import sys
import platform
import subprocess
import json
import threading
import tkinter as tk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tkinter import filedialog, messagebox
from tkinter import scrolledtext
from core.metadata import MetadataHandler


class ContactPanel:
    """
    EN: Contact Sheet GUI panel
    CN: 底片索引图形界面面板
    """
    
    def __init__(self, parent, lang="en"):
        """
        Args:
            parent: Parent widget / 父部件
            lang: UI language ("zh" or "en") / 界面语言（"zh" 或 "en"）
        """
        self.parent = parent
        self.worker_thread = None
        self.film_list = []
        self.lang = lang  # EN: Use provided language / CN: 使用传入的语言
        self.meta = MetadataHandler()  # EN: Initialize metadata handler / CN: 初始化元数据处理器
        self.setup_ui()
        self.load_film_library()
    
    def setup_ui(self):
        """
        EN: Setup user interface
        CN: 设置用户界面
        """
        # EN: Create Two-Column Layout Container using PanedWindow / CN: 使用可拖动的 PanedWindow 创建双栏布局容器
        self.main_container = ttk.Panedwindow(self.parent, orient=tk.HORIZONTAL)
        self.main_container.pack(fill=BOTH, expand=YES, padx=10, pady=10)
        
        # EN: Left panel for scrollable settings and pinned bottom button / CN: 固定宽度的左侧容器
        self.left_panel = ttk.Frame(self.main_container, width=750)
        self.left_panel.pack_propagate(False)
        self.main_container.add(self.left_panel, weight=0)
        
        # Bottom actions in left side
        self.bottom_left_frame = ttk.Frame(self.left_panel)
        self.bottom_left_frame.pack(side=BOTTOM, fill=X, pady=(10, 0))

        # Scrolled settings area inside the remaining left space
        from ttkbootstrap.widgets.scrolled import ScrolledFrame
        self.left_scrolled = ScrolledFrame(self.left_panel, autohide=True)
        self.left_scrolled.pack(side=TOP, fill=BOTH, expand=YES)
        self.left_frame = self.left_scrolled # Directly use ScrolledFrame as parent
        
        self.right_frame = ttk.Frame(self.main_container)
        self.main_container.add(self.right_frame, weight=1)

        # EN: Create a container for format and orientation side-by-side / CN: 创建格式和方向的并排容器
        top_container = ttk.Frame(self.left_frame)
        top_container.pack(fill=X, pady=(0, 10))
        
        # EN: Format display (auto-detected, read-only) / CN: 画幅显示（自动检测，只读）
        format_text = "画幅" if self.lang == "zh" else "Format"
        self.format_frame = ttk.Labelframe(top_container, text=format_text, padding=10)
        self.format_frame.pack(side=LEFT, fill=BOTH, expand=YES, padx=(0, 5))
        
        self.format_var = ttk.StringVar(value="")
        format_label = ttk.Label(self.format_frame, textvariable=self.format_var, font=("Microsoft YaHei UI", 11, "bold"), foreground="#2780e3")
        format_label.pack(side=LEFT, anchor=W, pady=5)
        
        # EN: State flag for half-frame / CN: 半格模式状态标志
        self.half_frame_var = ttk.BooleanVar(value=False)
        
        # EN: Manual switch to 135HF (Toolbutton style) / CN: 手动切换到 135HF (工具按钮样式开关)
        hf_btn_text = "半格模式" if self.lang == "zh" else "Half-Frame"
        self.hf_button = ttk.Checkbutton(self.format_frame, text=hf_btn_text, variable=self.half_frame_var, 
                                        command=self.on_hf_toggle, bootstyle="info-toolbutton", width=12)
        self.hf_button.pack(side=RIGHT, padx=(5, 0))
        
        # EN: Store the actual format value separately / CN: 单独存储实际的画幅值
        self.detected_format = ""
        
        # EN: Orientation selection (for 645 & 135HF) / CN: 方向选择（针对 645 和 135HF）
        orient_text = "排版方向" if self.lang == "zh" else "Orientation"
        self.orientation_frame = ttk.Labelframe(top_container, text=orient_text, padding=10)
        self.orientation_frame.pack(side=LEFT, fill=BOTH, expand=YES, padx=(5, 0))
        self.orientation_frame.pack_forget()  # Hide initially / 初始隐藏
        
        self.orientation_var = ttk.StringVar(value="L")
        self.orientations = [
            ("L", "垂直条 (L) - 横向照片", "Vertical strip (L) - Landscape"),
            ("P", "水平条 (P) - 竖向照片", "Horizontal strip (P) - Portrait")
        ]
        
        self.orientation_radios = []
        for value, text_zh, text_en in self.orientations:
            radio_text = text_zh if self.lang == "zh" else text_en
            radio = ttk.Radiobutton(self.orientation_frame, text=radio_text, variable=self.orientation_var, 
                          value=value, bootstyle="primary")
            radio.pack(anchor=W, pady=2)
            self.orientation_radios.append(radio)
        
        # EN: Input folder / CN: 输入文件夹
        folder_text = "输入文件夹" if self.lang == "zh" else "Input Folder"
        self.folder_frame = ttk.Labelframe(self.left_frame, text=folder_text, padding=10)
        self.folder_frame.pack(fill=X, pady=(0, 10))
        
        input_row = ttk.Frame(self.folder_frame)
        input_row.pack(fill=X, pady=(0, 5))
        
        self.input_folder_var = ttk.StringVar()
        ttk.Entry(input_row, textvariable=self.input_folder_var, state="readonly").pack(side=LEFT, fill=X, expand=YES, padx=(0, 5))
        
        # EN: Refresh button / CN: 刷新按钮
        refresh_text = "刷新" if self.lang == "zh" else "Refresh"
        self.refresh_button = ttk.Button(input_row, text=refresh_text, command=self.refresh_format, bootstyle="info-outline", width=8)
        self.refresh_button.pack(side=RIGHT, padx=(2, 5))
        
        browse_text = "浏览" if self.lang == "zh" else "Browse"
        self.browse_button = ttk.Button(input_row, text=browse_text, command=self.select_input_folder, bootstyle="info-outline")
        self.browse_button.pack(side=RIGHT)
        
        no_folder_text = "未选择文件夹" if self.lang == "zh" else "No folder selected"
        self.file_count_label = ttk.Label(self.folder_frame, text=no_folder_text, foreground="gray")
        self.file_count_label.pack(anchor=W)
        
        # EN: Auto-detect photos_in / CN: 自动检测 photos_in
        self.auto_detect_photos_in()
        
        # EN: Film selection / CN: 胶片选择
        film_info_text = "胶片信息" if self.lang == "zh" else "Film Information"
        self.film_info_frame = ttk.Labelframe(self.left_frame, text=film_info_text, padding=10)
        self.film_info_frame.pack(fill=X, pady=(0, 10))
        
        self.auto_detect_var = ttk.BooleanVar(value=True)
        auto_detect_text = "自动识别胶片（从EXIF）" if self.lang == "zh" else "Auto Detect from EXIF"
        self.auto_detect_check = ttk.Checkbutton(self.film_info_frame, text=auto_detect_text, 
                       variable=self.auto_detect_var, command=self.on_auto_detect_changed, 
                       bootstyle="round-toggle")
        self.auto_detect_check.pack(anchor=W, pady=(0, 5))
        
        film_row = ttk.Frame(self.film_info_frame)
        film_row.pack(fill=X, pady=5)
        manual_text = "手动选择:" if self.lang == "zh" else "Manual Select:"
        self.manual_label = ttk.Label(film_row, text=manual_text, width=20)
        self.manual_label.pack(side=LEFT)
        
        self.film_combo = ttk.Combobox(film_row, state="disabled")
        self.film_combo.pack(side=LEFT, fill=X, expand=YES)
        
        # EN: Emulsion number / CN: 乳剂号（可选）
        row3 = ttk.Frame(self.film_info_frame)
        row3.pack(fill=X, pady=5)
        emulsion_text = "乳剂号 (可选):" if self.lang == "zh" else "Emulsion No. (optional):"
        self.emulsion_label = ttk.Label(row3, text=emulsion_text, width=20)
        self.emulsion_label.pack(side=LEFT)
        self.roll_id_var = ttk.StringVar(value="")
        ttk.Entry(row3, textvariable=self.roll_id_var).pack(side=LEFT, fill=X, expand=YES)

        # EN: Display and Sort options
        # CN: 显示与排序选项
        options_row = ttk.Frame(self.film_info_frame)
        options_row.pack(fill=X, pady=5)
        
        # 1. EN: Date/EXIF toggles / CN: 日期与EXIF开关
        self.show_date_var = ttk.BooleanVar(value=True)
        self.show_exif_var = ttk.BooleanVar(value=True)
        date_text = "显示日期" if self.lang == "zh" else "Show Date"
        exif_text = "显示EXIF" if self.lang == "zh" else "Show EXIF"
        self.show_date_check = ttk.Checkbutton(options_row, text=date_text, variable=self.show_date_var, bootstyle="round-toggle")
        self.show_date_check.pack(side=LEFT, padx=(0, 10))
        self.show_exif_check = ttk.Checkbutton(options_row, text=exif_text, variable=self.show_exif_var, bootstyle="round-toggle")
        self.show_exif_check.pack(side=LEFT)

        self.show_exif_check = ttk.Checkbutton(options_row, text=exif_text, variable=self.show_exif_var, bootstyle="round-toggle")
        self.show_exif_check.pack(side=LEFT)

        # 2. EN: Sorting / CN: 图片排序
        sort_row = ttk.Frame(self.film_info_frame)
        sort_row.pack(fill=X, pady=5)
        sort_label_text = "图片排序:" if self.lang == "zh" else "Image Sort:"
        self.sort_label = ttk.Label(sort_row, text=sort_label_text, width=20)
        self.sort_label.pack(side=LEFT)
        
        self.sort_var = ttk.StringVar()
        self.sort_combo = ttk.Combobox(sort_row, textvariable=self.sort_var, state="readonly")
        self.sort_combo.pack(side=LEFT, fill=X, expand=YES)
        self.setup_sort_options()
        
        # EN: Generate button / CN: 生成按钮
        generate_text = "全卷缩略图" if self.lang == "zh" else "Contact Sheet"
        self.generate_button = ttk.Button(self.bottom_left_frame, text=generate_text, 
                                         command=self.start_generation, bootstyle="success", width=30)
        self.generate_button.pack(pady=(5, 5))
        
        self.progress = ttk.Progressbar(self.bottom_left_frame, mode="indeterminate", bootstyle="success-striped")
        self.progress.pack(fill=X, pady=(0, 5))
        self.progress.pack_forget()  # Hide initially
        
        # EN: Log output / CN: 日志输出 (Now in right_frame)
        log_text = "生成日志" if self.lang == "zh" else "Generation Log"
        self.log_frame = ttk.Labelframe(self.right_frame, text=log_text, padding=5)
        self.log_frame.pack(fill=BOTH, expand=YES, pady=(0, 10))
        
        # EN: Set minimum height for log area / CN: 设置日志区域最小高度
        self.log_text = scrolledtext.ScrolledText(self.log_frame, height=25, wrap=tk.WORD, state="disabled")
        self.log_text.pack(fill=BOTH, expand=YES, padx=2, pady=2)
    
    def select_input_folder(self):
        """
        EN: Open folder selection dialog
        CN: 打开文件夹选择对话框
        """
        folder = filedialog.askdirectory(
            title="选择输入文件夹" if self.lang == "zh" else "Select Input Folder",
            initialdir=self.input_folder_var.get() or os.path.expanduser("~")
        )
        if folder:
            self.input_folder_var.set(folder)
            self.update_file_count()
            # EN: Auto-detect format from first image / CN: 从第一张照片自动检测画幅
            self.detect_and_set_format(folder)
    
    def auto_detect_photos_in(self):
        """
        EN: Auto-detect photos_in folder and detect format from first image
        CN: 自动检测 photos_in 文件夹并从第一张照片检测画幅
        """
        try:
            if getattr(sys, 'frozen', False):
                working_dir = os.path.dirname(sys.executable)
            else:
                working_dir = os.getcwd()
            
            photos_in = os.path.join(working_dir, "photos_in")
            if os.path.exists(photos_in):
                self.input_folder_var.set(photos_in)
                self.update_file_count()
                
                # EN: Auto-detect format from first image / CN: 从第一张照片自动检测画幅
                self.detect_and_set_format(photos_in)
        except Exception as e:
            # EN: Auto-detection failed, log to GUI / CN: 自动检测失败，记录到GUI
            # Note: This runs during init, log widget may not be ready yet, so silent fail is OK
            pass
    
    def detect_and_set_format(self, folder):
        """
        EN: Detect format from first image in folder
        CN: 从文件夹中的第一张照片检测画幅
        """
        try:
            files = [f for f in os.listdir(folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            if files:
                img_path = os.path.join(folder, files[0])
                detected_format = self.meta.detect_batch_layout([img_path])
                if detected_format:
                    self.detected_format = detected_format
                    # EN: Display only format code / CN: 只显示画幅代码
                    self.format_var.set(detected_format)
                    
                    # EN: Show/hide orientation frame based on format / CN: 根据画幅显示/隐藏方向选择
                    if detected_format in ["645_6x8_43", "135HF"]:
                        self.orientation_frame.pack(side=LEFT, fill=BOTH, expand=YES, padx=(5, 0), after=self.format_frame)
                    else:
                        self.orientation_frame.pack_forget()
                    
                    # EN: Set half-frame state / CN: 设置半格状态
                    if detected_format == "135HF":
                        self.half_frame_var.set(True)
                    else:
                        self.half_frame_var.set(False)
        except Exception:
            pass

    def on_hf_toggle(self):
        """EN: Handle Half-Frame toggle / CN: 处理半格模式开关切换"""
        is_on = self.half_frame_var.get()
        if is_on:
            self.detected_format = "135HF"
            self.format_var.set("135HF")
            self.orientation_frame.pack(side=LEFT, fill=BOTH, expand=YES, padx=(5, 0), after=self.format_frame)
            msg = "已开启半格模式 (135HF)" if self.lang == "zh" else "Half-Frame Mode (135HF) ON"
        else:
            # EN: Revert to 135_6x9 or detect again / CN: 切回 135_6x9 或重新检测
            self.detected_format = "135_6x9"
            self.format_var.set("135_6x9")
            self.orientation_frame.pack_forget()
            msg = "已关闭半格模式 / Standard 135 Mode" if self.lang == "zh" else "Half-Frame Mode OFF"
        self.log(f"✓ {msg}")
    
    def refresh_format(self):
        """
        EN: Manually refresh format detection and file count from current input folder
        CN: 手动刷新当前输入文件夹的画幅检测和文件数量
        """
        folder = self.input_folder_var.get()
        if not folder or not os.path.exists(folder):
            msg = "请先选择输入文件夹" if self.lang == "zh" else "Please select input folder first"
            messagebox.showwarning("警告" if self.lang == "zh" else "Warning", msg)
            return
        
        # EN: Update file count / CN: 更新文件数量
        self.update_file_count()
        
        # EN: Detect format / CN: 检测画幅
        self.detect_and_set_format(folder)
        
        # EN: Show success message / CN: 显示成功消息
        if self.detected_format:
            msg = f"已刷新画幅: {self.detected_format}" if self.lang == "zh" else f"Format refreshed: {self.detected_format}"
            self.log(f"✓ {msg}")
        else:
            msg = "未能检测到画幅" if self.lang == "zh" else "Could not detect format"
            self.log(f"⚠ {msg}")
    
    def update_file_count(self):
        """
        EN: Update file count display
        CN: 更新文件数量显示
        """
        folder = self.input_folder_var.get()
        if not folder or not os.path.exists(folder):
            text = "未选择文件夹" if self.lang == "zh" else "No folder selected"
            self.file_count_label.config(text=text, foreground="gray")
            return
        
        try:
            files = [f for f in os.listdir(folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            count = len(files)
            if count > 0:
                text = f"✓ 找到 {count} 张照片" if self.lang == "zh" else f"✓ Found {count} photos"
                self.file_count_label.config(text=text, foreground="green")
            else:
                text = "⚠ 文件夹中没有图片" if self.lang == "zh" else "⚠ No images in folder"
                self.file_count_label.config(text=text, foreground="red")
        except Exception as e:
            text = f"错误: {e}" if self.lang == "zh" else f"Error: {e}"
            self.file_count_label.config(text=text, foreground="red")
    
    def update_language(self, lang):
        """
        EN: Update UI language
        CN: 更新界面语言
        """
        self.lang = lang
        
        if lang == "zh":
            self.format_frame.config(text="画幅")
            self.orientation_frame.config(text="排版方向")
            for i, radio in enumerate(self.orientation_radios):
                _, text_zh, _ = self.orientations[i]
                radio.config(text=text_zh)
            
            self.folder_frame.config(text="输入文件夹")
            self.refresh_button.config(text="刷新")
            self.browse_button.config(text="浏览")
            self.film_info_frame.config(text="胶片信息")
            self.auto_detect_check.config(text="自动识别胶片（从EXIF）")
            self.manual_label.config(text="手动选择:")
            self.emulsion_label.config(text="乳剂号 (可选):")
            self.show_date_check.config(text="显示日期")
            self.show_exif_check.config(text="显示EXIF")
            self.hf_button.config(text="半格模式")
            self.sort_label.config(text="图片排序:")
            self.setup_sort_options()
            self.generate_button.config(text="全卷缩略图")
            self.log_frame.config(text="生成日志")
            self.update_film_combo_values()
        else:
            self.format_frame.config(text="Format")
            self.orientation_frame.config(text="Orientation")
            for i, radio in enumerate(self.orientation_radios):
                _, _, text_en = self.orientations[i]
                radio.config(text=text_en)
            
            self.folder_frame.config(text="Input Folder")
            self.refresh_button.config(text="Refresh")
            self.browse_button.config(text="Browse")
            self.film_info_frame.config(text="Film Information")
            self.auto_detect_check.config(text="Auto Detect from EXIF")
            self.manual_label.config(text="Manual Select:")
            self.emulsion_label.config(text="Emulsion # (optional):")
            self.show_date_check.config(text="Show Date")
            self.show_exif_check.config(text="Show EXIF")
            self.hf_button.config(text="Half-Frame")
            self.sort_label.config(text="Image Sort:")
            self.setup_sort_options()
            self.generate_button.config(text="Generate Contact Sheet")
            self.log_frame.config(text="Generation Log")
            self.update_film_combo_values()
        
        # EN: Refresh log with current language / CN: 使用当前语言刷新日志
        if self.film_list:
            self.log_text.config(state="normal")
            self.log_text.delete(1.0, tk.END)
            self.log_text.config(state="disabled")
            msg = f"✓ 已加载 {len(self.film_list)} 种胶片" if lang == "zh" else f"✓ Loaded {len(self.film_list)} films"
            self.log(msg)
        
        # EN: Update file count display / CN: 更新文件数量显示
        self.update_file_count()
    
    def update_film_combo_values(self):
        """
        EN: Update film combo box values with current language
        CN: 使用当前语言更新胶片下拉框选项
        """
        if not self.film_list:
            return
        
        placeholder = "-- 请选择胶片 --" if self.lang == "zh" else "-- Select Film --"
        film_names = [placeholder] + [name for name, _ in self.film_list]
        current = self.film_combo.current()
        self.film_combo['values'] = film_names
        self.film_combo.current(current if current >= 0 else 0)
    
    def load_film_library(self):
        """
        EN: Load film library from config
        CN: 从配置文件加载胶片库
        """
        try:
            # EN: Use MetadataHandler resolver to locate films.json in dev/onefile/_MEIPASS
            # CN: 通过 MetadataHandler 的路径解析器定位 films.json（开发/单文件/_MEIPASS 均可）
            config_path = MetadataHandler._resolve_config_path('films.json')
            
            with open(config_path, 'r', encoding='utf-8') as f:
                films_data = json.load(f)
            
            self.film_list = []
            for brand, films in films_data.items():
                for film_name in films.keys():
                    display_name = f"{brand} {film_name}"
                    self.film_list.append((display_name, film_name))
            
            self.film_list.sort()
            self.update_film_combo_values()
            
            msg = f"✓ 已加载 {len(self.film_list)} 种胶片" if self.lang == "zh" else f"✓ Loaded {len(self.film_list)} films"
            self.log(msg)
        except Exception as e:
            msg = f"✗ 胶片库加载失败: {e}" if self.lang == "zh" else f"✗ Film library load failed: {e}"
            self.log(msg)
    
    def on_auto_detect_changed(self):
        """
        EN: Handle auto-detect toggle
        CN: 处理自动检测切换
        """
        if self.auto_detect_var.get():
            self.film_combo.config(state="disabled")
        else:
            self.film_combo.config(state="normal")  # EN: Allow user input / CN: 允许用户输入
    
    def start_generation(self):
        """
        EN: Start contact sheet generation with thread safety check
        CN: 开始生成全卷缩略图（带线程安全检查）
        """
        # EN: Check if worker thread is already running / CN: 检查工作线程是否已在运行
        if self.worker_thread is not None and self.worker_thread.is_alive():
            title = "警告" if self.lang == "zh" else "Warning"
            msg = "生成任务正在运行中，请等待..." if self.lang == "zh" else "Generation task is already running, please wait..."
            messagebox.showwarning(title, msg)
            return
        
        # EN: Get input folder / CN: 获取输入文件夹
        input_folder = self.input_folder_var.get()
        if not input_folder or not os.path.exists(input_folder):
            title = "警告" if self.lang == "zh" else "Warning"
            msg = "请先选择输入文件夹" if self.lang == "zh" else "Please select input folder"
            messagebox.showwarning(title, msg)
            return
        
        files = [f for f in os.listdir(input_folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        if not files:
            title = "警告" if self.lang == "zh" else "Warning"
            msg = "输入文件夹中没有图片" if self.lang == "zh" else "No images in input folder"
            messagebox.showwarning(title, msg)
            return
        
        # EN: Get manual film / CN: 获取手动胶片
        manual_film = None
        if not self.auto_detect_var.get():
            # EN: Get either selected or manually typed film name / CN: 获取选中或手动输入的胶片名
            film_input = self.film_combo.get().strip()
            if not film_input or film_input.startswith("--"):
                title = "警告" if self.lang == "zh" else "Warning"
                msg = "请选择或输入胶片类型" if self.lang == "zh" else "Please select or enter film type"
                messagebox.showwarning(title, msg)
                return
            # EN: If it's from the list, extract the keyword / CN: 如果是列表中的，提取关键字
            manual_film = film_input
            for display_name, keyword in self.film_list:
                if film_input == display_name:
                    manual_film = keyword
                    break
        
        # EN: Setup output / CN: 设置输出
        if getattr(sys, 'frozen', False):
            working_dir = os.path.dirname(sys.executable)
        else:
            working_dir = os.getcwd()
        output_folder = os.path.join(working_dir, "photos_out")
        os.makedirs(output_folder, exist_ok=True)
        
        # EN: UI state / CN: UI状态
        self.log_text.config(state="normal")
        self.log_text.delete(1.0, "end")
        self.log_text.config(state="disabled")
        
        self.progress.pack(fill=X, pady=(0, 10))
        self.progress.start(10)
        self.generate_button.config(state="disabled")
        
        # EN: Collect parameters / CN: 收集参数
        # EN: Use detected format instead of ComboBox / CN: 使用检测到的画幅而非下拉框
        selected_format = self.detected_format
        
        # EN: Manual override: If Half-Frame is checked and format is 135, upgrade to 135HF
        if self.half_frame_var.get() and selected_format == "135_6x9":
            selected_format = "135HF"
        # EN: If already detected as 135HF, keep it
        elif self.half_frame_var.get() and not selected_format:
            selected_format = "135HF"
        elif not self.half_frame_var.get() and selected_format == "135HF":
            selected_format = "135_6x9"

        orientation = self.orientation_var.get() if selected_format in ["645_6x8_43", "135HF"] else None
        
        # EN: Map sort selection to parameters / CN: 将排序选择映射为参数
        sort_text = self.sort_var.get()
        sort_method = "name"
        reverse = False
        
        if self.lang == "zh":
            if "降序" in sort_text or "新 → 旧" in sort_text: reverse = True
            if "时间" in sort_text: sort_method = "date"
        else:
            if "Descending" in sort_text or "New to Old" in sort_text: reverse = True
            if "Date" in sort_text: sort_method = "date"

        params = {
            'format': selected_format,
            'manual_film': manual_film,
            'emulsion_number': self.roll_id_var.get().strip() or "",  # EN: Use empty string instead of None / CN: 使用空字符串而非None
            'orientation': orientation,  # EN: Add orientation parameter / CN: 添加方向参数
            'show_date': self.show_date_var.get(),
            'show_exif': self.show_exif_var.get(),
            'sort_method': sort_method,
            'reverse': reverse,
            'input_folder': input_folder,
            'output_folder': output_folder
        }
        
        # EN: Start worker thread / CN: 启动工作线程
        self.worker_thread = threading.Thread(
            target=self.generation_worker,
            args=(params,),
            daemon=True
        )
        self.worker_thread.start()
    
    def generation_worker(self, params):
        """
        EN: Worker thread for generation
        CN: 生成工作线程
        """
        try:
            from apps.contact_sheet import ContactSheetPro
            
            # EN: Progress callback / CN: 进度回调
            def progress_update(message):
                self.parent.after(0, lambda msg=message: self.log(msg))
            
            # EN: Create contact sheet instance / CN: 创建缩略图生成器实例
            contact = ContactSheetPro()
            
            # EN: Generate using the generate() method / CN: 使用generate()方法生成
            result = contact.generate(
                input_dir=params['input_folder'],
                orientation=params['orientation'],  # EN: Pass orientation parameter / CN: 传递方向参数
                output_dir=params['output_folder'],
                format=params['format'],
                manual_film=params['manual_film'],
                emulsion_number=params['emulsion_number'],
                show_date=params['show_date'],
                show_exif=params['show_exif'],
                sort_method=params['sort_method'],
                reverse=params['reverse'],
                lang=self.lang,  # EN: Localize messages / CN: 按当前语言输出
                progress_callback=progress_update
            )
            
            if result['success']:
                self.parent.after(0, lambda path=result['output_path']: self.on_generation_complete(path))
            else:
                self.parent.after(0, lambda msg=result['message']: self.on_generation_error(msg))
                
        except Exception as e:
            import traceback
            error_msg = f"{str(e)}\n\n{traceback.format_exc()}"
            self.parent.after(0, lambda msg=error_msg: self.on_generation_error(msg))
    
    def on_generation_complete(self, result_path):
        """
        EN: Handle generation completion
        CN: 生成完成回调
        """
        self.progress.stop()
        self.progress.pack_forget()
        self.generate_button.config(state="normal")
        
        self.log("\n✓ " + "="*50)
        msg1 = "✓ 生成完成！" if self.lang == "zh" else "✓ Generation complete!"
        msg2 = f"✓ 输出文件：{os.path.basename(result_path)}" if self.lang == "zh" else f"✓ Output: {os.path.basename(result_path)}"
        self.log(msg1)
        self.log(msg2)
        self.log("✓ " + "="*50)
        
        # EN: Show result dialog / CN: 显示结果对话框
        title = "完成" if self.lang == "zh" else "Complete"
        if self.lang == "zh":
            dialog_msg = (
                "全卷缩略图生成完成！\n\n"
                f"{os.path.basename(result_path)}\n\n"
                "是否打开输出文件夹？"
            )
        else:
            dialog_msg = (
                "Contact sheet generated!\n\n"
                f"{os.path.basename(result_path)}\n\n"
                "Open output folder?"
            )
        response = messagebox.askyesno(title, dialog_msg)
        if response:
            try:
                # EN: Cross-platform folder opening / CN: 跨平台打开文件夹
                output_dir = os.path.dirname(result_path)
                system = platform.system()
                if system == "Windows":
                    os.startfile(output_dir)
                elif system == "Darwin":  # macOS
                    subprocess.run(["open", output_dir])
                else:  # Linux and others
                    subprocess.run(["xdg-open", output_dir])
            except Exception as e:
                err_title = "错误" if self.lang == "zh" else "Error"
                err_msg = f"无法打开文件夹:\n{e}" if self.lang == "zh" else f"Failed to open folder:\n{e}"
                messagebox.showerror(err_title, err_msg)
    
    def on_generation_error(self, error_msg):
        """
        EN: Handle generation error
        CN: 生成错误回调
        """
        self.progress.stop()
        self.progress.pack_forget()
        self.generate_button.config(state="normal")
        
        msg = f"\n✗ 发生错误\n{error_msg}" if self.lang == "zh" else f"\n✗ Error occurred\n{error_msg}"
        self.log(msg)
        err_title = "错误" if self.lang == "zh" else "Error"
        if self.lang == "zh":
            dialog_msg = (
                "生成过程中发生错误：\n\n"
                f"{error_msg[:200]}...\n\n"
                "如需帮助请联系：xjames007@gmail.com"
            )
        else:
            dialog_msg = (
                "Error during generation:\n\n"
                f"{error_msg[:200]}...\n\n"
                "For help contact: xjames007@gmail.com"
            )
        messagebox.showerror(err_title, dialog_msg)
    
    def log(self, message):
        """
        EN: Append message to log
        CN: 添加消息到日志
        """
        self.log_text.config(state="normal")
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state="disabled")

    def setup_sort_options(self):
        """
        EN: Setup sorting options in Combobox
        CN: 设置排序下拉框选项
        """
        if self.lang == "zh":
            options = [
                "文件名 (升序)",
                "文件名 (降序)",
                "拍摄时间 (旧 → 新)",
                "拍摄时间 (新 → 旧)"
            ]
        else:
            options = [
                "Filename (Ascending)",
                "Filename (Descending)",
                "Date (Old to New)",
                "Date (New to Old)"
            ]
        self.sort_combo['values'] = options
        self.sort_combo.current(0)
