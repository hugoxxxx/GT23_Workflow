# core/metadata.py
import os
import sys
import json
import exifread
from fractions import Fraction
from PIL import Image
from utils.config_manager import config_manager

class MetadataHandler:
    def __init__(self, layout_config='layouts.json', films_config='films.json', contact_config='contact_layouts.json'):
        """ EN: Refined MetadataHandler - Strictly preserves structure, fixes keyword matching.
             CN: 核心逻辑修复版：严格保留结构，修复关键字匹配路径。
        """
        # EN: Resolve config paths (dev, onefile, onedir/_internal)
        # CN: 解析配置路径，兼容开发与打包 (_internal)
        self.layout_path = self._resolve_config_path(layout_config)
        self.films_path = self._resolve_config_path(films_config)
        self.contact_path = self._resolve_config_path(contact_config)

        with open(self.layout_path, 'r', encoding='utf-8') as f:
            self.layout_db = json.load(f)
        with open(self.films_path, 'r', encoding='utf-8') as f:
            self.films_map = json.load(f)
        with open(self.contact_path, 'r', encoding='utf-8') as f:
            self.contact_layouts = json.load(f)

        # --- [精准重构] 扁平化特征映射表：匹配即所得 ---
        # CN: 将 edge_code 和 color 直接绑定到特征词上，实现一次匹配全属性交付
        self.feature_db = {}
        for brand, films in self.films_map.items():
            for std_name, info in films.items():
                # EN: Create an attribute bundle for each film
                # CN: 封装属性包：包含标准名、喷码和视觉颜色
                attr_bundle = {
                    "std_name": std_name,
                    "edge_code": info.get('edge_code', std_name.upper()),
                    "color": info.get('visual', {}).get('edge_marking_color', [245, 130, 35, 210])
                }

                # EN: Map std_name and features to the same bundle
                # CN: 建立特征索引：标准名 + 特征列表 (如 P400) 全指向同一个属性包
                self.feature_db[std_name.upper()] = attr_bundle
                for feat in info.get('features', []):
                    self.feature_db[feat.upper()] = attr_bundle

        # EN: Sort by length descending to prevent partial matching (e.g., 'Portra' vs 'Portra 400')
        # CN: 按长度倒序排列特征词，确保长词（如 PORTRA 400）优先于短词（如 PORTRA）被匹配
        self.sorted_features = sorted(self.feature_db.keys(), key=len, reverse=True)


    @staticmethod
    def _resolve_config_path(filename):
        """
        EN: Robust config path resolver for dev / onefile / onedir(_internal).
        CN: 兼容开发与打包 (_internal) 的配置路径解析。
        """
        if os.path.isabs(filename):
            return filename

        candidates = []

        # 0. EN: Check Managed "config" folder first (highest user priority)
        # CN: 极高优先级：托管资产下的 config 文件夹 (用户最容易找到并编辑的地方)
        managed_config = config_manager.get_managed_path("config", filename)
        candidates.append(managed_config)

        # 1. EN: Check in decoupled Assets Repo (legacy subfolders)
        # CN: 检查解耦的资产仓库中的子文件夹 (如 GT23_Assets/films)
        if "films.json" in filename:
            candidates.append(config_manager.get_managed_path("films", filename))
        
        candidates.append(config_manager.get_managed_path(filename=filename))

        # 2. EN: Determine internal base (system or bundled)
        # CN: 确定内部资源基准路径
        if getattr(sys, 'frozen', False):
            base_dir = sys._MEIPASS
        else:
            # metadata.py is in core/, so we go up 1 level to reach root
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        # 3. EN: Internal fallback paths / CN: 内部回退路径 (assets/config or config)
        candidates.append(os.path.join(base_dir, "assets", "config", filename))
        candidates.append(os.path.join(base_dir, "config", filename))

        # 4. CWD/config (for development)
        candidates.append(os.path.join(os.getcwd(), 'config', filename))

        # 5. Frozen exe dir /config and /_internal/config (for packaged apps)
        if getattr(sys, 'frozen', False):
            exe_dir = os.path.dirname(sys.executable)
            # EN: Check in synchronized Assets folder / CN: 检查同步来的资产文件夹
            candidates.append(os.path.join(exe_dir, 'GT23_Assets', 'films', filename))
            candidates.append(os.path.join(exe_dir, 'GT23_Assets', filename))
            
            # EN: Standard packaged paths / CN: 标准打包路径
            candidates.append(os.path.join(exe_dir, 'config', filename))
            candidates.append(os.path.join(exe_dir, '_internal', 'config', filename))
            if hasattr(sys, '_MEIPASS'):
                candidates.append(os.path.join(sys._MEIPASS, 'config', filename))

        # 3) Source tree relative to this file
        base_dir = os.path.dirname(os.path.abspath(__file__))
        candidates.append(os.path.join(os.path.dirname(base_dir), 'config', filename))

        for path in candidates:
            if os.path.exists(path):
                return path

        raise FileNotFoundError(f"Config file not found: {filename}. Tried: {candidates}")


    def match_film(self, raw_input):
        if not raw_input:
            return None
        q = str(raw_input).strip().upper()
        for feat in self.sorted_features:
            if feat in q:
                return self.feature_db[feat]["std_name"]
        return None


    def get_data(self, img_path, is_digital_mode=False, manual_film=None):
        """ CN: 核心数据提取逻辑。 [必要修改 2/3] 增加 manual_film 参数默认值，确保 Renderer66/67 等调用不报错。 """
        with open(img_path, 'rb') as f:
            tags = exifread.process_file(f, details=False)

        # --- 基础 EXIF 提取逻辑 (完全保留，不改动任何变量名) ---
        make = str(tags.get('Image Make', 'Unknown'))
        model = str(tags.get('Image Model', 'Unknown'))
        lens = str(tags.get('EXIF LensModel', 'Unknown Lens'))
        f_num = tags.get('EXIF FNumber')
        aperture_str = str(float(f_num.values[0])) if f_num else None
        expo = tags.get('EXIF ExposureTime')
        shutter_str = str(expo.values[0]) if expo else None
        focal = tags.get('EXIF FocalLength')
        focal_val = float(focal.values[0].num) / float(focal.values[0].den) if focal else 0
        focal_str = f"{int(focal_val)}mm" if focal_val > 0 else None
        dt = tags.get('EXIF DateTimeOriginal') #or tags.get('Image DateTime')
        dt_str = str(dt.values) if dt else ""
        iso = tags.get('EXIF ISOSpeedRatings')
        iso_str = str(iso.values[0]) if iso else ""

        # --- [核心逻辑修复] 三级识别引擎 ---
        display_film = ""
        edge_code = "FILM" # EN: Default value when film not detected / CN: 无法识别胶片时的默认值
        contact_color = (245, 130, 35, 210)

        if not is_digital_mode:
            # EN: If manual film is specified, use it directly (priority over auto-detection)
            # CN: 如果指定了手动胶片，直接使用（优先于自动识别）
            if manual_film:
                m_q = manual_film.upper().strip()
                manual_bundle = None
                for feat in self.sorted_features:
                    if feat == m_q or feat in m_q:
                        manual_bundle = self.feature_db[feat]
                        break

                if manual_bundle:
                    display_film = manual_film
                    edge_code = manual_film.upper()
                    contact_color = tuple(manual_bundle["color"])
                else:
                    # EN: If not found in database, use as-is
                    # CN: 如果数据库中找不到，原样使用
                    display_film = manual_film
                    edge_code = manual_film.upper()
            else:
                # EN: Auto-detection from EXIF (only when manual_film is not specified)
                # CN: 从EXIF自动识别（仅在未指定手动胶片时）
                # 1. 自动扫描 (合并多个 Description 字段以体现专业性)
                d1 = str(tags.get('Image ImageDescription', ''))
                d2 = str(tags.get('EXIF UserComment', ''))
                d3 = str(tags.get('EXIF ImageDescription', ''))
                # 补充扫描位
                search_pool = f"{d1} {d2} {d3}".upper()

                # 2. 尝试自动识别
                auto_bundle = None
                for feat in self.sorted_features:
                    if feat in search_pool:
                        auto_bundle = self.feature_db[feat]
                        break

                if auto_bundle:
                    display_film = auto_bundle["std_name"]
                    edge_code = auto_bundle["edge_code"]
                    contact_color = tuple(auto_bundle["color"])

        # --- 布局参数计算 (完全保留) ---
        with Image.open(img_path) as img:
            w, h = img.size
            ratio = max(w, h) / min(w, h)
            is_portrait = h > w

        layout_params = {"name": "CUSTOM", "side": 0.04, "top": 0.04, "bottom": 0.13, "font_scale": 0.032, "is_portrait": is_portrait}
        for name, cfg in self.layout_db.items():
            r_min, r_max = cfg['aspect_range']
            if (r_min - 0.01) <= ratio <= (r_max + 0.01):
                params = cfg.get("portrait" if is_portrait else "landscape", cfg.get("all"))
                layout_params = {"name": name, "side": params['side_ratio'], "top": params.get('top_ratio', params['side_ratio']), "bottom": params['bottom_ratio'], "font_scale": params.get('font_scale', 0.032), "is_portrait": is_portrait}
                break

        return {
            'Make': make,
            'Model': model,
            'LensModel': lens,
            'ExposureTimeStr': shutter_str,
            'FNumber': aperture_str,
            'ISO': iso_str,
            'FocalLength': focal_str,
            'DateTime': dt_str,
            'Film': display_film,
            'EdgeCode': edge_code,
            'ContactColor': contact_color,
            'is_digital': is_digital_mode,
            'layout': layout_params
        }


    def detect_batch_layout(self, img_paths):
        with Image.open(img_paths[0]) as img:
            w, h = img.size
            ratio = max(w, h) / min(w, h)
            is_portrait = h > w
        
        # EN: Map aspect ratio to layout name / CN: 将宽高比映射到布局名称
        if 0.95 <= ratio <= 1.05:
            return "6x6"
        if 1.09 <= ratio <= 1.28:
            return "6x7_4x5"
        
        # EN: Distinguish between 645 (120 film, ~15 frames) and 135HF (135 film, 72 frames)
        # CN: 区分 645 (120 胶卷，约 15 张) 和 135HF (135 胶卷，72 张)
        if 1.28 <= ratio <= 1.42:
            if len(img_paths) > 32: # EN: Likely 135 Half-Frame / CN: 大概率是 135 半格
                return "135HF"
            return "645_6x8_43"

        if 1.42 <= ratio <= 1.70:
            return "135_6x9"
        if 1.70 <= ratio <= 5.0:
            return "PANORAMIC"
        return "135_6x9"  # EN: Default to 135 / CN: 默认为135


    def get_contact_layout(self, key):
        return self.contact_layouts.get(key, self.contact_layouts["135"])