# core/renderers/renderer_66.py
import random
from PIL import Image, ImageDraw
from .base_renderer import BaseFilmRenderer

class Renderer66(BaseFilmRenderer):
    """
    EN: 6x6 Renderer. Strictly returns canvas to prevent NoneType errors.
    CN: 中英双语：66 渲染器。严格返回画布对象，防止主程序出现 NoneType 报错。
    """
    def render(self, canvas, img_list, cfg, meta_handler, user_emulsion):
        print("CN: [Renderer] 正在执行 66 画幅喷码安全渲染...")
        draw = ImageDraw.Draw(canvas)
        
        # --- 1. 参数加载 ---
        # 120胶片物理比例 (61.5mm / 56.0mm)
        FILM_RATIO = 61.5 / 56.0 
        m_x, m_y_t = cfg['margin_x'], cfg['margin_y_top']
        c_gap, r_gap = cfg['col_gap'], cfg['row_gap']
        cols, rows = 3, 4 # 66画幅标准 12 张
        c_w, c_h = canvas.size
        
        # --- 2. 物理尺寸预计算 ---
        # 计算每一条垂直底片条的可用宽度
        strip_area_w = (c_w - 2 * m_x - (cols - 1) * c_gap) // cols
        # 照片边长（根据底片条宽度反推，预留喷码空间）
        side_length = int(strip_area_w / FILM_RATIO)
        # 实际底片条宽度
        strip_w = int(side_length * FILM_RATIO)

        # 获取样式数据
        sample_data = meta_handler.get_data(img_list[0])
        cur_color = sample_data.get("ContactColor", (245, 130, 35, 210))
        film_brand = sample_data.get("FilmModel", "KODAK")

        # --- 3. 绘制垂直底片条与左侧喷码 ---
        for c in range(cols):
            # 底片条中心 X 坐标
            cx = m_x + (strip_area_w // 2) + c * (strip_area_w + c_gap)
            sx = cx - strip_w // 2 # 底片条左边缘
            
            # 绘制黑色底片背景
            draw.rectangle([sx, m_y_t - 60, sx + strip_w, c_h - cfg['margin_y_bottom'] + 60], fill=(12, 12, 12))
            
            # 侧边随机喷码
            edge_txt = f"{user_emulsion}  {film_brand} SAFETY FILM"
            edge_layer = self.create_rotated_text(edge_txt, 90, color=cur_color)
            
            curr_y = m_y_t - 20
            base_step = side_length + r_gap
            for _ in range(rows):
                # 喷码放在照片左侧的空隙里
                text_x = int(sx + 8) 
                canvas.paste(edge_layer, (text_x, int(curr_y + random.randint(10, 50))), edge_layer)
                curr_y += base_step

        # --- 4. 渲染照片与右侧帧号 ---
        for i, path in enumerate(img_list[:12]):
            c, r = i // rows, i % rows
            cx = m_x + (strip_area_w // 2) + c * (strip_area_w + c_gap)
            row_y = m_y_t + r * (side_length + r_gap)
            
            # A. 粘贴照片
            with Image.open(path) as img:
                # 66 强制正方形缩放
                img = img.resize((side_length, side_length), Image.Resampling.LANCZOS)
                canvas.paste(img, (int(cx - side_length // 2), int(row_y)))

            # B. 绘制右侧标识 (三角形 + 帧号)
            # 帧号放在照片右侧的黑边里
            tri = self.create_stretched_triangle(color=cur_color)
            num_str = str(i + 1)
            num_layer = self.create_rotated_text(num_str, 90, color=cur_color)
            
            # 物理定位：底片条右边缘往回缩一点
            rx = (cx - strip_w // 2) + strip_w - num_layer.width - 12
            canvas.paste(tri, (int(rx), int(row_y + side_length//2 - 70)), tri)
            canvas.paste(num_layer, (int(rx + 2), int(row_y + side_length//2 + 20)), num_layer)

        # --- 5. 关键修复：返回画布 ---
        # EN: Crucial! Return the finished canvas to main logic.
        # CN: 必须返回 canvas，否则主程序保存时会报 NoneType 错误。
        return canvas