# Change Log / 变更日志

## [2.4.1] - 2026-04-24
🎞️ v2.4.1 核心更新：字体解耦资产化 & 高精度齿孔渲染引擎 & 自定义边框文字

### 🖋️ 字体系统解耦 (Font Decoupling & Assetization)
- **[Feature] 外部字体动态加载 / Dynamic External Fonts**:
  - EN: Decoupled font management. The app now scans `GT23_Assets/fonts` for `.ttf`, `.otf`, and `.ttc` files.
  - CN: 实现了字体系统的全面解耦。程序现在会动态扫描 `GT23_Assets/fonts` 目录下的 `.ttf`、`.otf` 和 `.ttc` 文件。
- **[Feature] 双标题独立字体选择 / Independent Font Path Selection**:
  - EN: Added font path dropdowns for Main and Subtitle. Users can now assign different external fonts to different text hierarchy levels.
  - CN: 新增了主副标题独立的字体路径选择下拉框。创作者可以根据审美需求，为型号和参数指定完全不同的外部字体。
- **[UX] 默认字体回退机制 / Smart Font Fallback**:
  - EN: Integrated "Default" option for fonts to ensure out-of-the-box usability while prioritizing external overrides if selected.
  - CN: 集成了“Default”默认字体选项，确保开箱即用的稳定性，同时支持一键切换至选定的外部字体，实现了真正的资产隔离。

### ⚙️ 齿孔渲染与自定义边框 (Sprocket Rendering & Custom Border)
- **[Feature] 高精度矢量齿孔渲染 / High-Precision Vector Sprockets**:
  - EN: Ported the high-precision BH-1866 movie film sprocket rendering engine to the main renderer. Uses SVG + CairoSVG for sub-pixel anti-aliased geometry.
  - CN: 移植了高精度 BH-1866 电影胶片齿孔渲染引擎。采用 SVG + CairoSVG 矢量技术，实现了次像素级的抗锯齿几何呈现。
- **[Feature] 自定义齿孔文字 / Custom Sprocket Text**:
  - EN: Added custom text rendering in the sprocket area. Supports using EXIF tags (Film/EdgeCode) or manual text entry with color-coded "Film Orange" styling.
  - CN: 支持在齿孔边框区域绘制自定义文字。可自动提取 EXIF 中的卷名/编号，或手动输入，并默认采用经典的“胶片橙”配色方案。
- **[Interactive] 实时齿孔开关 / Live Sprocket Toggle**:
  - EN: Added "Enable Sprockets" switch and text entry in Advanced Settings for instantaneous preview feedback.
  - CN: 在高级设置面板新增了“开启齿孔边框”开关与文字输入框，支持预览界面瞬间响应，创作直观快捷。

### 🛠️ 稳定性与 UI 优化 (Stability & UI Refinement)
- **[Architecture] 资源引导加固 / Asset Bootstrap Hardening**:
  - EN: Re-engineered `bootstrap_fonts` logic to align with Logo search patterns, supporting both production EXE environments and development Git repos.
  - CN: 重构了字体引导逻辑 `bootstrap_fonts`，使其与 Logo 检索模式对齐，完美支持生产环境 EXE 与开发分支目录结构。
- **[Fix] 胶片库加载冗余修复 / Film Library Load Fix**:
  - EN: Resolved a code merging issue in `BorderPanel` where font loading inadvertently overwritten the film library initializer.
  - CN: 修复了 `BorderPanel` 中的一个合并低级错误，确保字体库与胶卷库在初始化阶段各归其位。

## [2.4.0] - 2026-04-23
💎 v2.4.0 核心更新：石板青 (Slate Teal) 审美重构 & 预设持久化 & 架构稳定性加固

### 📸 构图精度与平移控制 (Compositional Precision)
- **[Feature] 构图平移（双轴）/ Compositional Offset (Dual-Axis)**:
  - EN: Implemented independent Vertical (U/D) and Horizontal (L/R) sliders with integer-only numeric entry for precise photo positioning.
  - CN: 实现了独立的双轴构图平移。支持垂直（上下）与水平（左右）像素级位移调节，且配备了强刷整型输入的输入框，确保构图极其精准。
- **[Feature] 非破坏性自适应边框 / Non-Destructive Adaptive Margins**:
  - EN: Refactored locked-ratio distribution to use an "Expansion-Only" strategy, preserving existing margins on the non-expanding axis when switching ratios.
  - CN: 重构了比例锁定下的边距分发逻辑。切换比例时，系统采用“增量分发”策略，仅补足所需留白，而不会像旧版那样粗暴地重置侧边边距。
- **[Aesthetics] 构图防撞安全区 / Text Safety Buffer**:
  - EN: Integrated a 550px `TEXT_RESERVE` buffer to prevent the photo from overlapping metadata during extreme downward shifts.
  - CN: 引入了 550 像素的“防撞缓冲区”。即使将照片大幅向下平移，系统也会强制保留底部元数据空间，确保文字永不被照片覆盖。
- **[UX] 刷新即重置 / Refresh to Reset**:
  - EN: Enhanced the "Refresh" button to restore all compositional offsets and sync states to defaults while re-scanning the folder.
  - CN: 强化了“刷新”按钮功能。点击刷新在重新扫描的同时，会一键将构图位移、字体偏移清零并恢复左右同步，为创作者提供快速“回血”重来的捷径。

### 💾 预设持久化与生产力增强 (Persistence & Productivity)
- **[UX] 全面组件化与外观统一 / Global UI Polish**:
  - EN: Unified metadata toggles to `round-toggle` style and standardized action buttons to `outline-primary` blue for a professional, distraction-free sidebar.
  - CN: 侧边栏全面视觉进化。将所有 EXIF 显隐开关统一为 `round-toggle` 圆形切换开关，并统合了动作按键配色，显著提升了“石板青”主题的视觉完成度。
- **[Feature] 审美预设系统 / Border Presets**:

### 🎨 UI 极简交互重构 (Aesthetic UI Refactor)
- **[Feature] “主题与比例”分组置顶 / Theme & Aspect Branding**:
  - EN: Reorganized the settings sidebar into two distinct groups. "Theme & Aspect (主题与比例)" is now placed at the top to prioritize creative decisions over technical parameters.
  - CN: 重构了设置面板的层级逻辑。将“主题与比例 (Theme & Aspect)”独立成组并置于最顶端，将创作风格与参数微调分离，操作逻辑更加契合摄影创作直觉。
- **[Feature] 5:7 画幅支持与社交标签 / Social Media Ratios**:
  - EN: Added 5:7 Instagram-native ratio support. Refined platform-specific labels for WeChat (1:1), Xiaohongshu (3:4), and Instagram (5:7).
  - CN: 新增了 5:7 (Instagram 标准) 画幅支持。细化了社交平台标签：1:1（微信朋友圈）、3:4（小红书）、5:7（Instagram），简化其他数字标注。
- **[Feature] 品牌色全面迭代 (Obsidian → Slate Teal)**:
  - EN: Updated application theme to "Slate Teal" with Gamma 1.6 optical simulation and multi-layered diffuse shadows.
  - CN: 品牌色全面迭代。由原有的“黑曜石”升级为具有工业美感的“石板青 (Slate Teal)”，并引入 Gamma 1.6 光学仿真渲染与多层结构化漫反射投影模型。

### 📏 联动逻辑与稳定性 (Logic & Stability)
- **[Feature] 比例锁定自适应联动 / Adaptive Proportional Sync**:
  - EN: Implemented a proportional padding calculator. In locked-ratio mode, manually adjusting one dimension (Width or Height) will automatically update the other to maintain the target aspect ratio perfectly.
  - CN: 实现了比例锁定下的自适应联动。在选择固定比例（如 1:1, 3:4）时，手动修改某一遍距，系统会自动计算并填补其余边际，确保整体画幅死死咬定在目标比例。
- **[UX] 事件驱动刷新 (回车/失焦) / Event-Based Refresh**:
  - EN: Optimized preview rendering to trigger only on `Return` (Enter) or `FocusOut` (blur) events. Eliminated real-time jitter during typing for a more premium, distraction-free input experience.
  - CN: 预览重绘机制由“实时触发”升级为“确认触发”。现在仅在按下回车或鼠标失焦时触发渲染，彻底消除了连续打字时的界面跳闪，操作体验更加沉稳流畅。
- **[Fix] 变量类型与鲁棒性加固 / StringVar Migration**:
  - EN: Migrated border and font variables to `StringVar` to natively handle temporary empty states during input, resolving all `TclError` crashes during rapid parameter editing.
  - CN: 将边距与字号变量从 `IntVar` 迁移至 `StringVar`。完美兼容输入框中途为空或非法字符的情况，彻底杜绝了因数值不匹配导致的 `TclError` 异常闪退。
品牌色全面迭代 (Obsidian → Slate Teal)

### 🛠️ 系统稳定性与路径加固 (System Stability & Path Hardening)
- **[Fix] Windows 路径全链路归一化 / Path Normalization**:
  - EN: Enforced strict path normalization (`os.path.normcase`) across `BorderController`, `ThumbnailStrip`, and `TypoEngine`. Resolved critical bugs where Windows case/slash variations caused configuration desync and redundant font loading.
  - CN: 在 `BorderController`、`ThumbnailStrip` 和 `TypoEngine` 中强制实施了全链路路径归一化 (`os.path.normcase`)。彻底解决了 Windows 系统下因路径大小写及斜杠差异导致的配置不同步、样片选中失效以及字体重复加载等顽疾。
- **[Fix] 样片条删除同步修复 / Thumbnail Strip Sync**:
  - EN: Applied path normalization to widget creation and deletion logic, ensuring the "Delete" action always stays in sync with the internal batch state.
  - CN: 将路径归一化应用于样片条的创建与删除逻辑，确保界面点击“删除”后，后台批次列表能精准同步更新。

### 📏 布局逻辑深度解耦 (Layout Decoupling & Stability)
- **[Feature] 底部边框绝对控制 / Absolute Bottom Border Control**:
  - EN: Completely decoupled the footer area from side/top margins. The "Bottom Border (px)" setting now represents the absolute height of the white area, with text automatically vertically centered.
  - CN: 实现了底部边框逻辑的深度解耦。删除了底层的隐藏边距关联，现在“底部边框 (px)”数值即为实打实的留白高度，且文字会在该区域内自动垂直居中，不再受侧边或顶部留白变化的干扰。
- **[UX] 模式切换逻辑优化 / Mode-Switch UI Stability**:
  - EN: Replaced dynamic hiding with state-based disabling (`_set_frame_enabled`) for mode-specific UI fields. Eliminated frustrating layout shifts and jumping when switching between Digital/Film/Pure modes.
  - CN: 优化了模式切换时的 UI 行为。将动态隐藏改为状态禁用 (`_set_frame_enabled`)，彻底消除了在数码/胶片/纯净模式切换时界面产生的抖动与跳变，保证了操作逻辑的连贯性。

### 🔄 智能配置同步 (Smart Configuration Sync)
- **[Feature] 同类设置一键同步 / Global Settings Sync**:
  - EN: Added "Apply to Similar Images" in Advanced Settings. Automatically identifies images in the batch with matching format (aspect ratio) and rotation to batch-apply border and theme settings.
  - CN: 在高级设置中新增了“同步到同类图片”功能。可一键识别批次中**同画幅（宽高比一致）且同旋转方向**的照片，并将当前的边框比例、主题及字号设置批量应用，显著提升多图处理效率。

### 🎨 审美重构 (Aesthetics Overhaul)
色彩对齐：通过多点采样，将原有的数字灰色重构为具工业质感的“空明石板青”。
全链路更名：已手动完成了 `renderer.py`、`BorderController.py` 和 `SettingsGroup.py` 的同步更名，界面下拉菜单现已正式显示“石板青 (Slate Teal)”。
Gamma 1.6 渲染引擎 (光学仿真)

通透感增强：引入了 1.6 伽态非线性校正，模拟自然光的物理衰减曲线。这消除了传统数字渐变的沉闷感，为背景营造出了极其开阔的“空气呼吸感”。
多层结构化漫反射投影 (物理悬浮模型)

重构投影逻辑：由简单的 Drop Shadow 升级为三层 Gaussian 复合模糊系统。
悬浮质感：模拟了真实环境光下的全方位漫射，使得照片不仅是垂直贴合，而是呈现出一种“利落悬浮”于石板上的高级物理座落感，边缘过渡极为自然。
UI 易读性优化 (Contrast Up)

副文字提亮：将 EXIF 信息等辅助文字的灰度从 161 暴力提升至 215 (#D7DEE4)，确保在石板青深色背景上具备磁吸般的阅读清晰度。
技术细节与鲁棒性

去色块化 (Anti-Banding)：通过高频抖动算法，解决了 8bit 色深下大面积渐变可能出现的阶跃色块问题。
边缘净化：优化了阴影的“负扩张”算法，彻底消除了深色模式下常见的边缘“灰环”和截断。
总结：现在的石板青主题已具备样片级的“通透、轻盈、悬浮”美学，非常适合展现具有德味（Voigtländer）影调的照片。您直接运行 main.py 刷新后即可体验。

### 🏗️ 架构重构与上帝对象拆解 (Architecture Refactor & God-Object Decoupling)
- **[Refactor] 核心控制逻辑离岸化 / Core Logic Off-shoring**:
  - EN: Successfully refactored the 1800-line monolithic `BorderPanel` into a lean 900-line modular structure. Migrated all business state (configs, caches, file scanning) to `BorderController`.
  - CN: 成功将 1800 余行的单体上帝对象 `BorderPanel` 重构为 900 行左右的精简模块化架构。将所有业务状态（配置、缓存、文件扫描逻辑）下沉至 `BorderController`。
- **[Component] UI 组态化封装 / Componentized UI Wrapper**:
  - EN: Extracted `ThumbnailStrip`, `ExifGroup`, and `SettingsGroup` into independent reusable components. Improved code readability and maintainability.
  - CN: 抽离了`ThumbnailStrip`（样片条）、`ExifGroup`（EXIF 组）和 `SettingsGroup`（设置组）为独立的复用组件，极大提升了代码的可读性和可维护性。
- **[Stabilization] “核能级”代码清理 / "Nuclear" Code Cleanup**:
  - EN: Resolved invisible binary character corruption and encoding issues by performing a full reconstruction of `BorderPanel.py` from a verified UTF-8 buffer.
  - CN: 通过对 `BorderPanel.py` 进行全量 UTF-8 缓冲区重构，物理消除了工具对位失败导致的所有不可见脏字符与编码乱码问题。
- **[Fix] 接口对位与导入修复 / Interface Alignment & Import Fixes**:
  - EN: Restored missing `scrolledtext` imports and fixed residual `AttributeError` in `refresh_input_folder` caused by the logic migration.
  - CN: 补全了精简过程中缺失的 `scrolledtext` 导入，并修复了 `refresh_input_folder` 中由于变量迁移未对位导致的 `AttributeError`。

### 📏 像素级布局与排版进化 (Pixel-Level Layout & Typography)
- **[Feature] 独立字号控制 / Independent Font Scaling**:
  - EN: Decoupled model (Main) and parameter (Sub) font sizes with dedicated input controls. Removed fixed scaling ratios for maximum layout flexibility.
  - CN: 实现了型号 (Main) 与参数 (Sub) 字号的完全独立控制。废除了固定比例约束，支持像素级独立微调。
- **[Feature] 实时溢出与压图预警 / Real-time Overflow & Overlap Radar**:
  - EN: Implemented a dual-axis warning system. Automatically detects horizontal text overflow and vertical image overlap (collision), providing real-time UI feedback with suggested maximum font sizes.
  - CN: 实现了双轴实时预警系统。可自动检测文字水平溢出与垂直压图（碰撞），并在预览界面实时展示警告信息及建议的最大安全像素值。
- **[Feature] 文字垂直位移微调 / Text Vertical Offset Control**:
  - EN: Added "Text Vertical Offset (px)" in Advanced Settings, allowing precise vertical repositioning of the entire text block to balance composition or avoid overlaps.
  - CN: 在高级设置中新增了“文字垂直偏移 (px)”项。支持整块文字的上下像素级位移微调，方便平衡构图或手动避开画面干扰。
- **[Fix] 渲染内核数值对位修复 / Renderer Precision Fixes**:
  - EN: Resolved `NameError` for `resolved_main` and `ref_factor` in the rendering pipeline. Fixed pixel rounding errors in preview mode to eliminate false overflow alarms.
  - CN: 修复了渲染流水层中 `resolved_main` 与 `ref_factor` 变量未定义的 Bug。解决了预览模式下的像素舍入精度误差，彻底排除了默认字号下的“假性报警”。

### 📸 品牌专属镜头设计 (Brand-Specific Lens Styling)
- **[Feature] 旗舰镜头视觉增强 / Flagship Lens Enhancements**:
  - EN: Implemented robust, regex-based detection for Canon L (Red), Nikon N (Gold), Sony GM (Token), and Sigma Art/Sports/Contemporary (Tokens). Added a global toggle in GUI with unified styling to enable/disable these stylings.
  - CN: 为旗舰镜头引入了专属视觉风格与勋章系统。通过正则精准识别 Canon L（红）、Nikon N（金）、Sony GM 与 Sigma A/S/C（勋章），并在“高级设置”中增加了全局开关（已统一视觉风格），支持随时切换至纯文本模式。

### 💎 磨砂玻璃极致视觉重构 (Frosted Glass Depth Overhaul)
- **[Feature] 物理级悬浮投影 / Physical Floating Shadow**:
  - EN: Implemented **Negative Spread + Rounded Masks** to eliminate gray ring artifacts and hard edges.
  - EN: Introduced **Air Falloff (Self-Vanishing)** algorithm where shadow opacity naturally decays from 100% to 20% along the displacement vector for realistic perspective.
  - CN: 实现了**负扩张 + 超大圆角遮罩**，物理级解决了投影中的“灰环”与生硬边缘问题。
  - CN: 引入**“空气衰减”自消隐算法**，阴影不透明度随位移自动降阶（从 100% 渐变至 20%），完美模拟真实侧光下的透视虚化感。
- **[Feature] 离屏复合渲染 / Off-screen Composite Pipeline**:
  - EN: Shifted to a 4-layer off-screen RGBA composite buffer with `Image.alpha_composite` for sub-pixel smooth gradients.
  - CN: 切换为 4 层离屏 RGBA 复合渲染。先在透明缓冲区完成投影层的物理融合，再整体贴回背景，彻底消除层叠处的“阶跃”感。
- **[Optimization] 文字配色智能自适应 / Adaptive Contrast Typography**:
  - EN: Added **Footer Brightness Sensing**. Automatically toggles between 5-level grayscale palettes (Carbon Black/Silver White) based on sampled background luminance.
  - CN: 接入**底部区域亮度感应系统**。自动根据背景明度切换文字配色（深碳黑/亮银白等五阶动态灰度），确保在任何复杂背景下均清晰可读。
- **[Stabilization] GUI 鲁棒性加固 / GUI Robustness**:
  - EN: Implemented global `_get_float_safe` fuses for all layout parameters. Fixed crashes caused by `float division by zero` and empty Tkinter entries during live preview.
  - CN: 为所有布局参数加装了 `_get_float_safe` 全链路“保险丝”。修复了因输入框删空导致的 Tkinter `TclError` 及渲染内核的“除以零”崩溃，显著提升预览稳定性。
- **[Optimization] 数码系统去胶片化 / Digital Metadata De-filming**:
  - EN: Automatically excludes film-specific metadata for digital camera systems to maintain a clean, professional parameters line.
  - CN: 针对数码摄影系统，在识别到数码机身时自动屏蔽胶片信息（不再显示 Film Name），使整体排版更符合现代数字摄影审美。
- **[Feature] 多路径 Logo 检索 / Multi-Path Logo Resolver**:
  - EN: Upgraded asset lookup to check both root source and distribution distribution folders, resolving missing logos for flagship models like Sony A1.
  - CN: 升级了相机 Logo 检索引擎，支持多路径（源码 + dist 离线库）同步搜索，彻底解决了部分旗舰机型（如 Sony A1）Logo 无法匹配的路径识别死角。

## [2.3.1] - 2026-04-06

### 🎨 样片与演示系统 (Samples & Showcase)
- **[Feature] 18 度灰专业样片 / 18° Gray Samples**:
  - EN: Updated official sample backgrounds to 18% gray with hardware-matched focal lengths and apertures for professional reference.
  - CN: 将演示样片背景升级为专业 18 度中性灰，并实现了元数据（焦距、光圈等）与当前镜头规格的 1:1 动态匹配，显著提升演示样片的拟真度。
- **[Feature] 品牌勋章全家桶 / Branding Showreel**:
  - EN: Added a vertically stacked branding showcase image in `assets/samples/branding_v241.jpg` for quick layout review. Includes a global toggle in GUI with unified styling to enable/disable these stylings.
  - CN: 在 `assets/samples` 目录下新增了品牌勋章全家桶展示图（branding_v241.jpg），一屏看全主流品牌与勋章的排版效果。并在 GUI 增加了风格统一的全局开关。

## [2.3.1] - 2026-04-06

### 📸 EXIF 元数据增强 (EXIF Metadata Enhancement)
- **[Feature] 原图 EXIF 保留与回写 / EXIF Preservation & Write-back**:
  - EN: Exported JPEG images now preserve original EXIF metadata (Date, GPS, etc.) and support manual overrides for Make, Model, Lens, Shutter, Aperture, and ISO using `piexif`.
  - CN: 导出 JPEG 图片现在能完整保留原图 EXIF 信息（如日期、地理位置等），并支持通过 `piexif` 库将手动输入的品牌、型号、镜头、快门、光圈、ISO 等参数精准回写至图片底层。
- **[Feature] 全局应用锁定系统 / Global Sync Lock System**:
  - EN: Added a "Apply to All" toggle for EXIF overrides. When locked, the override values are synchronized across all images in the current batch.
  - CN: 为 EXIF 覆盖字段新增了“全局应用”开关。开启后，填写的参数将自动同步至当前批次内的所有图片，实现一处修改、全量生效。

### 🐛 稳定性与修复 (Stability & Fixes)
- [Fix] PhotoImage 线程安全修复 / PhotoImage Thread-Safety:
  - EN: Fixed `AttributeError: 'PhotoImage' object has no attribute '_PhotoImage__photo'` on startup by ensuring all `ImageTk.PhotoImage` instances are initialized on the main thread.
  - CN: 彻底修复了启动时可能出现的 `AttributeError: 'PhotoImage' object has no attribute '_PhotoImage__photo'` 报错。
- [Fix] 语言切换崩溃修复 / Language Switch Crash Fix:
  - EN: Resolved `AttributeError: 'NoneType' object has no attribute 'is_alive'` in `update_language()` before worker thread initialization.
  - CN: 修复了 `update_language()` 中由于 `worker_thread` 尚未初始化即调用 `is_alive()` 导致的崩溃问题。
- [Fix] 列表删除同步修复 / List Deletion Sync Fix:
  - EN: Fixed a bug where deleting items from the thumbnail strip did not correctly update the export batch list.
  - CN: 修复了在样片条中点击删除后，后台导出路径列表未实时同步更新的 Bug。
- [Fix] 深色模式白边修复 / Dark Mode Edge Artifact Fix:
  - EN: Automatically skips shadow rendering and utilizes a black flattening background in Dark theme to eliminate white edge artifacts on mobile OLED screens.
  - CN: 在 Dark 主题下自动跳过阴影渲染，并使用黑色背景进行 JPG 复合，彻底消除移动端 OLED 屏上的边缘白脏边。


### 📂 有序批量导出 (Ordered Batch Export)
- **[Feature] 马卡龙 & 彩虹排序命名 / Ordered Naming for Specialty Themes**:
  - EN: Output filenames in Macaron and Rainbow modes now follow the adjusted GUI sorting order by including a numeric prefix (e.g., `001_`, `002_`).
  - CN: 马卡龙与彩虹模式下的批量导出文件名现在会增加数字前缀（如 `001_`, `002_`），以严格遵循用户在 GUI 中手动调整后的样片排序。
- **[UX] 胶片选择交互优化 / Film Selection UX Optimization**:
  - EN: Selecting an item from the film dropdown or pressing Enter after manual input now triggers an immediate preview refresh.
  - CN: 胶片下拉选择框支持在选择项变更或敲击回车时自动触发预览刷新。

### ⚡ 瞬时预览与架构重塑 (Instant Preview & Architecture)
- **[Performance] 全内存渲染管线 / Memory-Only Pipeline**:
  - EN: Implemented a memory-only rendering pipeline with source image caching, reducing preview latency from 1300ms to <200ms (an 85% speedup).
  - CN: 实现了“全内存转向”渲染管线与源图缓存机制。通过在内存中驻留 1200px 预缩放底图，消除了参数调整时的磁盘 I/O 与重复缩放开销，反馈延迟从 1.3s 降低至 0.2s 以内。
- **[Aesthetics] 高保真阴影还原 / High-Fidelity Preview Shadow**:
  - EN: Restored high-quality GaussianBlur (radius=20) for previews while maintaining instant responsiveness. Fixed alpha-blending issues for memory-only output.
  - CN: 在保留即时响应的同时，还原了高质量的高斯模糊阴影 (radius=20)。修复了内存模式下由于 Alpha 通道未复合导致的预览黑边问题。

### 📦 资源同步与鲁棒性增强 (Assets Sync & Robustness)
- **[Assets] Logo 库全量同步 / Logo Library Sync**:
  - EN: Synchronized 37 new logos (198 total) including Sony A7CII, A7R5, and Leica M11 series.
  - CN: 全面同步了 198 款相机 Logo 资源，新增对索尼 A7CII、A7R5、徕卡 M11-P/D、M10-R 等最新机型的支持。
- **[Feature] 索引自动刷新 / Catalog Refresh**:
  - EN: Regenerated all 20 UI catalog pages and the full map to reflect the updated logo library.
  - CN: 重新生成了 UI 内部使用的 20 页分页索引图及单张全量预览总表，确保新资源在应用内即刻可见。
- **[Fix] GBK 环境编码修复 / Windows Encoding Fix**:
  - EN: Resolved crashes in Windows GBK terminal environments when printing Unicode checkmarks.
  - CN: 彻底解决了 Windows GBK 环境下因控制台打印 Unicode 勾选字符导致的渲染程序崩溃问题。

## [2.3.3-alpha] - 2026-03-28

### 🎞️ 135 半格索引与排版重构 (135HF Precision Contact Sheet)
- **[Feature] 135HF 渲染器 v3.0 / Unified Strip Rotation**:
  - EN: Implemented a new "Unified Strip Rotation" architecture for P (Horizontal) and L (Vertical) modes, ensuring perfect 1:1 physical parity with symmetrical 0.5mm margins.
  - CN: 实现了 P/L 双模式统一旋转架构。底片条现在通过 90 度顺时针旋转实现垂直排列（L模式），修复了首尾留白非对称问题（各 0.5mm 完美平衡）。
  - EN: Fixed 72-frame slot enforcement (dark base color fill for missing slots) and center-cropping (ImageOps.fit) to prevent thumbnail stretching.
  - CN: 实现了强制 72 画幅条位补全（不足部分以底片基色填充），并引入了居中裁切算法，彻底告别非标比例导致的拉伸变形。
- **[Aesthetics] 强化底片细节 / High-Precision Film Assets**:
  - EN: Added rotated branding, numbering, and dual-sided vector sprockets (Standard KS / Movie BH-1866) for L-mode strips.
  - CN: 针对 L 模式垂直条进行了视觉加固：支持自动旋转的品牌名与数字标号，并完美适配双侧高精度矢量齿孔（支持切换电影卷/民用卷样式）。
- **[Interactive] “半格”模式开关 / Half-Frame UI Toggle**:
  - EN: Added a "Half-Frame" Toolbutton switch in the Format panel for manual orientation override and P/L mode selection.
  - CN: format 面板新增了工具按钮样式的“半格模式”开关。即使系统识别失效，用户也能一键强制切入半格逻辑，并同步开启 P/L 排版方向面板。

### 🎨 UI 交互与多语言适配 (UI Interaction & Localization)
- **[Feature] 纯净模式 / Pure Mode**:
  - EN: Introduced "Pure Mode" to suppress all text and logo overlays while preserving the border background.
  - CN: 新增“纯净模式”，可完全隐藏所有文字参数与相机 Logo，仅保留边框底色，满足极致简约需求。
- **[Feature] CJK 字库降级 / CJK Font Fallback**:
  - EN: Implemented automatic CJK character detection and system-default font fallback (Microsoft YaHei) for EXIF strings.
  - CN: 实现了 CJK 字符自动检测与系统字库自动降级逻辑，支持在手动覆盖字段中输入中文字符并正常渲染。
- **[Interactive] 回车即时刷新 / Enter-to-Refresh**:
  - EN: Added `<Return>` key bindings to all parameter entries for instant preview rendering update.
  - CN: 为设置面板中所有参数输入框绑定了回车事件，按下回车即刻触发现场预览重绘。
- **[Aesthetics] 边框主题 UI 降噪 / Theme Selector Refinement**:
  - EN: Simplified theme labels to pure single-language strings and increased dropdown width to 20 to prevent text clipping.
  - CN: 彻底简化了边框主题下拉框显示（移除冗余双语括号），并拓宽了组件宽度以确保长文本条目完整展示。
- **[Term] 术语对齐 / Terminology Alignment**:
  - EN: Renamed "Fuji Rainbow" to "Rainbow" and "Rainbow" (Macaron) to "Macaron" for better clarity.
  - CN: 将“富士彩虹”精简命名为“彩虹”，并将原马卡龙从内部 rainbow key 迁移至独立命名空间。
- **[Feature] 显隐状态独立持久化 / Per-Image EXIF Visibility**:
  - EN: EXIF visibility toggles are now stored independently for each image, preventing global configuration overrides.
  - CN: 实现了 EXIF 字段显隐开关的单图独立持久化，切换样片时将自动恢复其专属的可见性设置。
- **[Aesthetics] 马卡龙色系 9 宫格增强 / Macaron 9-Grid Optimization**:
  - EN: Expanded Macaron palette to 9 colors and implemented deterministic position-based indexing for 9-grid layouts.
  - CN: 将马卡龙色系扩展至 9 种，并实现了基于批次物理位置的确定性色彩分配，支持拖拽实时更新，完美适配“九宫格”。
- **[Fix] 渲染稳定性 / Rendering Stability**:
  - EN: Eliminated random color "jumping" by implementing MD5 path-hashing fallback and position-sync.
  - CN: 通过路径哈希与位置同步算法彻底解决了预览及排序时马卡龙色调随机跳变的 Bug。

## [2.3.2] - 2026-03-27

### 🌈 彩虹重构与样品模式 (Rainbow Reborn & Sample Mode)
- **富士全谱渐变 (Fuji Rainbow Batch Slicing)**: 实现了真正的“连续光谱长卷”逻辑。在批量处理时，系统会自动将完整的彩虹光谱动态等分为 N 份（基于导入照片总数），确保拼接后呈现出丝滑、连贯、高保真的一体化视觉感。针对“灰感”反馈进行了专项饱和度回调。
- **马卡龙双色随机渐变 (Macaron Dynamic Gradient)**: 针对马卡龙模式（rainbow）进行了高保真升级。单张照片现在支持基于索引的 **“双色线性渐变”**（如粉过渡到蓝），营造出极其灵动、梦幻的视觉表现。
- **官方演示模式 (SAMPLE Metadata Mode)**: 新增 `is_sample` 参数支持。开启后，渲染引擎将强制覆盖相机、镜头、参数、胶卷等所有元数据为 **“SAMPLE”** 占位符，完美适配商业展示与样片分发。
- **排版去反色加固 (Locked Dark Typography)**: 统一锁定了所有彩虹主题的字体配色为经典的 **“深空灰”**（浅色模式标准）。废除了亮度自适应反白逻辑，确保在一片绚烂背景中依然具备顶级的阅读清晰度。

## [2.3.0-alpha] - 2026-03-27

### 开发初始化 / Development Initialization
- **[Task] v2.3.0 周期启动 / Lifecycle Start**:
  - EN: Created `v2.3.0` branch and bumped global version to `2.3.0-alpha`.
  - CN: 开启 `v2.3.0` 开发分支，并将全局版本号更新至 `2.3.0-alpha`。
- **[Docs] 文档规范重构 / Documentation Standards**:
  - EN: Initialized v2.3.0 release notes and overhauled progress tracking artifacts to be bilingual according to new AI guidelines.
  - CN: 初始化 v2.3.0 发布说明，并根据新的 AI 准则将进度追踪文档重构为中英双语格式。

## [2.2.3] - 2026-03-25

### Core & Contact Sheet / 核心与底片索引
- **[Fix] Manual Film Name Preservation / 手动胶卷名称锁定**:
  - EN: Fixed an issue where manual film inputs were overwritten by standard database names; manual strings are now strictly preserved.
  - CN: 修复了手动输入的胶卷型号会被数据库标准格式覆盖的问题，现在系统会严格保留用户的原始输入（如 KODAK 5207）。
- **[Fix] 135 Emulsion Display / 135 乳剂号显示修复**:
  - EN: Resolved a bug in the 135 renderer where the emulsion number was hidden; it now displays correctly alongside the film name.
  - CN: 修复了 135 渲染器中乳剂号被隐藏的 Bug，现在乳剂号会与胶卷名正常拼接显示。
- **[Feature] Flexible Image Sorting / 灵活图片排序**:
  - EN: Added support for sorting contact sheet images by Filename or EXIF Date, with an optional Reverse toggle.
  - CN: 底片索引新增了“图片排序”功能，支持按文件名或拍摄时间排序，并提供一键倒序开关。

### GUI & Environment / 界面与用户体验
- **[Fix] Advanced Settings Layout / 高级设置布局修复**:
  - EN: Refactored the Advanced Settings and EXIF Overrides into a balanced Grid layout to prevent text clipping and ensure consistent column widths.
  - CN: 将“高级设置”与“EXIF 覆盖”重构为等宽格栅布局（Grid），彻底解决了由于字符长度导致的标签挤压与输入框对不齐问题。
- **[Stability] Robust Multi-Source Sync / 强力多源同步**:
  - EN: Enhanced asset sync with Gitee API Token (CAPTCHA bypass), physical file verification (force download if empty), and robust ZIP root detection.
  - CN: 彻底重构资源同步逻辑，引入 Gitee Token 绕过验证码，增加“物理文件检索”机制（空文件夹强制重下），并优化了 ZIP 压缩包根目录自动识别。
- **[Feature] Config Decoupling / 配置文件解耦**:
  - EN: Decoupled `layouts.json`, `films.json`, and `contact_layouts.json` into `GT23_Assets/config` for easy user editing; internal defaults are automatically exported on first run.
  - CN: 实现了配置文件的全面解耦，现在 `layouts.json`、`films.json` 与 `contact_layouts.json` 会在首次运行时自动释放到 `GT23_Assets/config` 目录，且优先于内置配置加载，方便用户直接修改参数。

## [2.2.3] - 2026-03-25

### Core & Functionality / 核心与功能
- **[Feature] Config Decoupling / 配置文件解耦**:
  - EN: Externalized `layouts.json` and `films.json` to `GT23_Assets/config/`. Users can now modify parameters without re-compiling.
  - CN: 将 `layouts.json` 和 `films.json` 配置文件外挂至 `GT23_Assets/config/`。由于实现了配置解耦，用户无需重新打包即可自定义边框与胶片参数。
- **[Feature] Manual Film Preservation / 手动胶卷名锁定**:
  - EN: Manual film strings are now strictly preserved and no longer overwritten by standard database matching.
  - CN: 实现了手动胶卷名称的强制锁定，确保用户手动输入的型号不再被数据库标准名覆盖。
- **[Feature] Flexible Image Sorting / 灵活图片排序**:
  - EN: Added filename and EXIF date sorting for contact sheets, including a reverse toggle.
  - CN: 索引页工具新增排序功能：支持按“文件名”或“拍摄时间”排序，并配备“倒序”开关。
- **[Fix] 135 Emulsion Display / 修复 135 乳剂号显示**:
  - EN: Resolved a bug where emulsion numbers were hidden in 135 format renders.
  - CN: 修复了 135 画幅渲染时乳剂号被隐藏的 Bug。

### Stability & Sync / 稳定性与同步
- **[Performance] Robust Multi-Source Sync / 强力多源同步**:
  - EN: Implemented physical file validation and Gitee Token mechanism to resolve "empty folder" download issues.
  - CN: 引入了物理文件校验与 Gitee API Token 机制，彻底解决了特定网络环境下同步成功但文件夹为空的问题。
- **[Aesthetics] 2026 Brand Icon / 2026 品牌图标更新**:
  - EN: Integrated high-resolution 2026 GT23 logo and generated multi-size .ico for Windows binaries.
  - CN: 集成了高清 2026 版 GT23 品牌图标，并为 Windows 版本同步生成了多尺寸 .ico 资源。
- **[Fix] UI Grid Alignment / 界面格栅对齐**:
  - EN: Refactored Advanced Settings with a uniform grid layout to prevent label crowding in different languages.
  - CN: 重构了高级设置面板的格栅布局，解决了多语言下标签重叠与对齐不均的问题。

## [2.2.2] - 2026-03-23

### Core & Efficiency / 核心与效率
- **[Performance] Extreme EXE Size Optimization / 极致 EXE 体积优化**:
  - EN: Slashed EXE size from ~200MB to **38.84 MB** (80% reduction) by purging 150MB+ of unused MKL/OpenMP binaries via manual `build.spec` filtering.
  - CN: 通过在 `build.spec` 中实施手动二进制过滤，彻底剔除 150MB+ 的冗余 MKL/OpenMP 库，将 EXE 体积从约 200MB 降至 **38.84 MB**，减重达 80%！
- **[Stability] Robust Sync Failover & Validation / 容错同步与签名校验**:
  - EN: Implemented automatic failover between GitHub and Gitee remotes. Added `PK\x03\x04` ZIP signature validation to prevent crashes from HTML error pages (404/Login redirects).
  - CN: 实现了 GitHub 与 Gitee 双源自动切换机制。新增了 `PK\x03\x04` ZIP 签名强制校验，有效防止因网络重定向或 404 HTML 页面导致的同步崩溃。
- **[Feature] Manual Image Rotation / 手动图像旋转**:
  - EN: Added minimalist, zero-background rotation icons (↺/↻) with 14pt primary color styling. Implemented automatic EXIF orientation fixing via `ImageOps.exif_transpose`.
  - CN: 新增了极简、无背景的旋转图标（↺/↻），采用 14pt 品牌色设计。引入了 `ImageOps.exif_transpose` 自动修复 EXIF 方向信息。
- **[Fix] Unified Rotation Logic / 统一旋转逻辑**:
  - EN: Fixed a critical bug where preview rotation was not passed to the batch engine. Now "What You See Is What You Get" is fully implemented for both single and batch renders.
  - CN: 修复了预览旋转角度未传递至批量引擎的 Bug，实现了单张预览与批量导出结果的完全一致。
- **[Fix] Batch Engine Stability / 批量引擎稳定性修复**:
  - EN: Resolved `NameError` and `UnboundLocalError` in `apps/border_tool.py` and fixed a UI bug where the completion dialog showed "0 photos processed".
  - CN: 解决了批量处理引擎中的变量定义报错，并修复了处理完成后弹窗错误显示“已处理 0 张照片”的统计 Bug。
- **[Architecture] Triple-Path Logic Alignment / 三位一体路径对齐**:
  - EN: Standardized asset pathing across Sync Engine, Renderer, and MetadataHandler to use a consistent `GT23_Assets` folder next to the EXE.
  - CN: 统一了同步引擎、渲染器与元数据处理器三方的路径逻辑，确保一键同步后图标与配置文件能立刻被软件精准识别。
- **[Feature] Smart Incremental Web Sync / 智能增量 Web 同步**:
  - EN: Implemented remote commit hash validation via Gitee/GitHub APIs; the app now skips redundant ZIP downloads if the asset library is already up to date.
  - CN: 引入了基于 Gitee/GitHub API 的远程 Commit Hash 校验机制；当资源库已是最新时，程序会自动跳过全量 ZIP 下载，极大节省了流量与同步时间。

### GUI & User Experience / 界面与用户体验
- **[Enhancement] Bilingual Sync Feedback Polish / 同步反馈双语优化**:
  - EN: Optimized the sync result dialog to display only the relevant language (EN or CN) based on current user settings, eliminating cluttered dual-language presentation.
  - CN: 优化了同步结果对话框的显示逻辑，根据用户当前语言设置精准展示单一语言（中文或英文），解决了之前“中英双语堆叠”导致的视觉凌乱。


### GUI & Stability / 界面与稳定性
- **[Fix] UI Stability Hotfix / 界面稳定性大修复**:
  - EN: Resolved `TclError` (pady/padx) and `NameError` in Settings and Sync dialogs by refactoring the core GUI logic and geometry management.
  - CN: 通过重构 GUI 核心逻辑与几何管理器，彻底解决了设置和同步对话框中的 `TclError`（pady/padx 参数错误）及 `NameError` 崩溃问题。
- **[Enhancement] Polished Settings UI / 深度优化设置界面**:
  - EN: Implemented a foolproof vertical layout for sync sources and adopted high-quality system fonts ("Microsoft YaHei" & "Segoe UI") to ensure crisp rendering and prevent text clipping in English mode.
  - CN: 引入了防呆式纵向同步源布局，并采用系统级原生字体（微软雅黑与 Segoe UI），确保了在高分屏下文字渲染精密且英文文本不再被截断。
- **[Feature] Dynamic "About" Dialog / 动态“关于”窗口**:
  - EN: Refactored the About dialog to dynamically pull version, author, and email info from `version.py`, ensuring data consistency across the app.
  - CN: 重构了“关于”对话框，使其版本、作者及联系信息自动与 `version.py` 同步，消灭了硬编码导致的数据滞后。
- **[Performance] Preview Debouncing Engine / 预览渲染防抖引擎**:
  - EN: Implemented a 300ms debounce timer for preview renders; successfully reduced redundant startup "Render Complete" logs from 5 lines to 1.
  - CN: 为预览渲染引入了 300ms 防抖机制，成功将启动时因初始化触发的冗余“渲染完成”日志从 5 条降至 1 条，显著优化了性能感。

### Assets & Synchronization / 资产与同步
- **[Architecture] Asset Decoupling (GT23_Assets) / 资产库彻底分离**:
  - EN: Decoupled 121+ camera logos into a standalone repository (`GT23_Assets`) and integrated it as a Git Submodule, significantly reducing main repository size and improving asset maintenance.
  - CN: 将 121+ 款相机图标彻底从主仓库剥离，建立独立的 `GT23_Assets` 资源库并以 Git Submodule 形式集成，大幅精简了主仓库体积并提升了资源维护效率。
- **[Feature] Dual-Remote Sync Strategy / 双源远程同步策略**:
  - EN: Implemented a robust dual-target synchronization system (GitHub + Gitee) with automatic failover, ensuring reliable asset updates regardless of network conditions in different regions.
  - CN: 实现了 GitHub + Gitee 双目标远程同步系统，支持自动故障切换，确保国内外用户在不同网络环境下都能稳定更新资源。
- **[Feature] "Sync Border Assets" One-Click Update / 一键资源同步功能**:
  - EN: Added a user-friendly sync feature in the Help menu that supports automatic ZIP download and extraction for users without a local Git environment.
  - CN: 在帮助菜单中新增了“同步边框资源”功能，支持在无 Git 环境下自动下载 ZIP 包并完成静默解压归位。
- **[Feature] Real-time Asset Statistics / 实时资产加载统计**:
  - EN: The Processing Log now displays the exact count of loaded camera logos (SVG+PNG) alongside the film count on startup.
  - CN: 程序启动日志现在会同步展示已加载的相机边框（SVG+PNG）实时总数，让资产库规模一目了然。
- **[Fix] Non-Git Sync Reliability / 修复 Git 环境缺失下的同步中断**:
  - EN: Resolved crashes in `asset_sync.py` by adding missing `os/sys` imports and refining the Web/ZIP fallback download sequence.
  - CN: 补全了 `asset_sync.py` 中缺失的 `os/sys` 导入，并优化了 Web/ZIP 模式下的降级下载流程，确保非开发环境下也能一键同步。


## [2.2.0] - 2026-03-14

### GUI & User Experience / 界面与用户体验
- [v2.2.0] Consolidate Android Migration Master Spec (Bilingual/Detailed)
- [v2.2.0] Massive logo library expansion (121 models) and asset decoupling via GT23_Assets submodule
- [v2.2.0] [GUI] Added "Sync Border Assets" feature in Help menu for one-click library updates
- **[Feature] One-Page Layout Optimization / “一页流”布局优化**:
  - EN: Redesigned settings panel with a wider 750px sidebar and a compact 2-column grid for Advanced Settings and EXIF Overrides.
  - CN: 重新设计了设置面板：将侧边栏宽度增至 750px，并将高频使用的“高级设置”与“EXIF 覆盖”调整为紧凑的双列网格布局。
- **[Enhancement] High-DPI & Visibility / 高分屏适配与可见性增强**:
  - EN: Increased default window height to 1100px to ensure core action buttons are visible without scrolling on most displays.
  - CN: 将默认窗口高度提升至 1100px，配合宽度调整，实现了核心功能“一眼全览”的目标，大幅减少了垂直滚动操作。
- **[Fix] UI Stability Hotfix / 界面稳定性修复**:
  - EN: Fixed an `AttributeError` during language switching and resolved a `TclError` caused by an invalid layout option.
  - CN: 修复了切换语言时可能出现的属性读取报错，并解决了因非法布局参数导致的启动崩溃问题。

### Assets & Customization / 资源与定制化
- **[Feature] External Logo Management / Logo 资源外置化**:
  - EN: Implemented auto-bootstrapping for logos; the app now automatically creates an external `logos/` folder next to the EXE for easy user customization.
  - CN: 实现了 Logo 资源的外置引导逻辑：程序在打包后首次运行时会自动在 EXE 同级目录下生成 `logos/` 文件夹，方便用户免打包增加自定义 Logo。
- **[Enhancement] Professional Neutral Reference / 专业中性预览参考**:
  - EN: Updated the official Logo Map with a professional neutral background for a clear visual reference of border and label interactions.
  - CN: 更新了官方 Logo 全景图，采用专业的中性背景，为摄影师提供更清晰的边框与标签交互预览参考。
- **[Fix] EOS R1 Logo Matching / 修复 EOS R1 图标匹配**:
  - EN: Renamed `EOS R1.png` to `CANON-EOS R1.png` to ensure correct automatic brand-model matching.
  - CN: 将 `EOS R1.png` 更名为 `CANON-EOS R1.png`，确保了该机型能根据 EXIF 数据自动匹配品牌图标。

### Build & Deployment / 构建与部署
- **[Feature] Versioned EXE Naming / EXE 文件名自动化版本管理**:
  - EN: Output executable now automatically includes version suffixes (e.g., `GT23_Workflow_v2.2.0.exe`).
  - CN: 生成的可执行文件现在会自动包含版本号后缀（如 `GT23_Workflow_v2.2.0.exe`），方便用户管理不同版本的安装包。
- **[Enhancement] Streamlined Build Script / 优化打包批处理**:
  - EN: Removed blocking `pause` commands in `build_gui.bat` for smoother automation and cleared file locks before building.
  - CN: 移除了 `build_gui.bat` 中的阻塞性 `pause` 命令，并在构建前自动清理文件占用，提升了打包过程的连贯性。


## [2026-03-13] - v2.1.1 Hotfix

### Logo Recognition & Assets / 图标识别与资源修复
- **[Fix] TVS Logo SVG Repair / 修复 TVS 图标受损**:
  - EN: Repaired corrupted `viewBox` in `CONTAX-TVS.svg` that caused it to render as an empty image.
  - CN: 修复了 `CONTAX-TVS.svg` 文件中损坏的 `viewBox` 属性（宽度为负值），解决了该机型图标渲染为空白的问题。
- **[Enhancement] Uniform Logo Scaling / 图标视觉尺寸统一化**:
  - EN: Implemented "Crop-then-Scale" logic to ensure all logos have identical visual height regardless of internal whitespace in the source files.
  - CN: 实现了“先裁剪后缩放”逻辑，通过物理剔除图标透明留白再进行等比缩放，确保了 30 余款不同品牌 Logo 在视觉上的整齐划一。
- **[Enhancement] Extreme Fuzzy Matching / 极端模糊匹配引擎**:
  - EN: Implemented symbol-agnostic matching that ignores spaces and hyphens (e.g., "TVS II" now correctly matches the "TVSII" asset).
  - CN: 引入了符号无关的匹配逻辑，自动忽略空格、横杠等特殊字符（例如：让 EXIF 中的 "TVS II" 能自动对准本地的 "TVSII" 图标资源）。

## [2026-03-11] - v2.1.0 Release

### Camera Logo & Typography / 相机图标与排版系统
- **[Feature] Vector Logo Support / 矢量图标支持**:
  - EN: Integrated high-quality SVG logos for Contax G/T/TVS series.
  - CN: 集成了 Contax G/T/TVS 等系列的高质量矢量 SVG 图标。
- **[Feature] PNG/Raster Logo Support / PNG 栅格图标支持**:
  - EN: Added support for bitmap logos (e.g., Pentax 67) to enhance user-defined camera identification.
  - CN: 增加了对位图图标（如 Pentax 67）的支持，允许用户自定义更多非矢量相机标识。
- **[Enhancement] Smart Model Matching / 智能型号匹配**:
  - EN: Implemented intelligence to detect popular models (G2, T3, 67, etc.) even when brand name (Make) is missing from EXIF.
  - CN: 实现了智能型号识别，即使 EXIF 中缺失品牌信息，也能自动匹配 G2, T3, 67 等机型的图标。
- **[Enhancement] Optical Centering (Ink BBox) / 视觉对齐 (Ink BBox)**:
  - EN: Re-engineered text/logo centering based on actual "Ink" pixels rather than character advance for pixel-perfect balance.
  - CN: 基于“墨迹像素”而非字符步进重构了对齐算法，确保 Logo 与文字在视觉中轴线上达到完美的物理对齐。
- **[Enhancement] Zeiss T* Highlight / 蔡司 T* 红色标识**:
  - EN: Automatically detects "T*" in lens models and renders it in standard Zeiss Red (#ed1f25).
  - CN: 自动检索镜头型号中的 "T*"，并将其渲染为蔡司标准的鲜红色 (#ed1f25)。

### Social Media & Performance / 社交平台与性能优化
- **[Feature] Pro JPEG Export / 专业 JPEG 导出流程**:
  - EN: Defaulted to ultra-high-resolution (4500px) and near-lossless (Quality 98) JPEG for maximum compatibility.
  - CN: 默认采用 4500px 超清分辨率与 98 几乎无损质量的 JPEG 导出，确保全平台最佳兼容性。
- **[Performance] Rendering Engine Overhaul (PNG to JPEG) / 渲染引擎重构 (PNG 切换为 JPEG)**:
  - EN: Switched from a high-compression PNG pipeline to an optimized JPEG workflow, delivering a **3x-5x faster rendering speed** while maintaining near-lossless quality.
  - CN: 渲染引擎由高压缩 PNG 流程全面重构为优化的 JPEG 流程。在保持几乎无损画质的前提下，**渲染速度提升了 3-5 倍**，实现秒级导出。
- **[Fix] Hardened Shadows (No More White Corners) / 阴影硬化 (彻底解决白角问题)**:
  - EN: Pre-flattens shadows on white background to prevent artifacts when social platforms (e.g., Xiaohongshu) compress images.
  - CN: 实现了阴影本地硬化复合，避免了小红书等平台在压缩透明底图时产生的“白色方块”或阴影丢失问题。
- **[Adjustment] Shadow Margin Refinement / 阴影边距精修**:
  - EN: Reduced shadow margin by 50% for a more compact and modern professional look.
  - CN: 将衬底阴影边距缩小了一半，使整体视觉效果更紧凑、更精致。

### Stability & UX / 稳定性与体验改进
- **[Fix] GUI Preview Hang / 修复 GUI 预览卡死**:
  - EN: Resolved hang caused by hardcoded .png extension; now dynamically tracks real output files.
  - CN: 修复了因硬编码 .png 后缀导致的 GUI 预览卡死问题，现在支持动态追踪实际输出格式。
- **[Fix] Logo Centering Collision / 修复 Logo 居中冲突**:
  - EN: Fixed variable shadowing bug that caused logos to be left-aligned instead of centered.
  - CN: 修复了一个变量名冲突导致的 Bug，该 Bug 曾导致 Logo 无法居中（靠左显示）。
- **[Fix] GUI Error Handling / 改进 GUI 异常处理**:
  - EN: Fixed NameError in exception dialogs to ensure error messages are properly displayed.
  - CN: 修复了异常对话框中的变量名错误，确保在运行出错时能正确弹出提示信息。


## [2026-02-01]

### Matin Slide Mode Re-engineering / 马田幻灯片模式重构
- **[Feature] Slide Master v4 (Precision Lightbox Edition) / 幻灯片“大师版 v4” (精密仿真)**:
  - EN: Strict brightness calibration: Board (#F5F5F5) > Mount (#E2E2E2). Fixed previous edge-inversion.
  - CN: 严格明暗校准：灯板 (#F5F5F5) > 片框 (#E2E2E2)。从根本上解决了边缘处亮度倒挂的问题。
  - EN: Recessed Inner Shadow: Implemented realistic depth using blurred masking instead of outlines.
  - CN: 真实内凹陷阴影：弃用机械描边，采用模糊蒙版技术模拟阶梯状的物理下陷感。
  - EN: Refined Bloom & Texture: 8-10px warm bloom and optimized 1.5% monochromatic noise.
  - CN: 优化溢光与纹理：应用 8-10px 暖色 Bloom 环境光与优化的 1.5% 单色噪点。

### Layout Calibration & Proportions / 布局校准与比例修复
- **[Fix] Scale-Aware Rendering / 感知缩放的渲染系统**:
  - EN: Refactored all internal offsets (text, corners, glow) to be proportional to cell size.
  - CN: 将所有内部偏移（文字、圆角、溢光）重构为相对于格口尺寸的比例计算，修复了预览图比例失准问题.
- **[Layout] Binder Hole Offset / 装订孔偏置校准**:
  - EN: Set fixed 20mm (472px) left margin for binder holes and implemented even horizontal distribution for gaps.
  - CN: 设置了固定的 20mm (472px) 左边距用于避让装订孔，并实现了等间距均布逻辑。
- **[Visual] Minimalist Cleanup / 视觉去装饰化**:
  - EN: Removed all legacy skip-shadows and bevels in favor of clean physical geometry.
  - CN: 移除了所有旧有的投影和倒角装饰，转向纯粹的物理几何呈现。

### Realistic Handwriting & Custom Labels / 真实手写体与自定义标签
- **[Feature] handright Library Integration / handright 库集成**:
  - EN: Integrated `handright` library for organic jitter in character rotation and spacing.
  - CN: 集成了 `handright` 库，实现了字符旋转和间距的自然随机抖动。
- **[Feature] Multiply Blend Mode / 正片叠底混合模式**:
  - EN: Applied Multiply blending for labels to simulate realistic oil marker ink on surfaces.
  - CN: 标签采用正片叠底模式绘制，模拟油性记号笔覆盖在表面上的真实观感。
- **[Feature] Font Selection & Bolding / 字体选择与加粗**:
  - EN: Added UI for font selection and implemented alpha dilation to simulate thicker marker strokes (Bold).
  - CN: 增加了字体选择 UI，并通过 Alpha 扩张算法模拟了更粗的记号笔笔触（加粗效果）。
- **[Fix] Font Size & Format Consistency / 字号与画幅一致性修复**:
  - EN: Fixed mismatch between single preview and final render by propagating `label_cfg` to all paths.
  - CN: 通过在所有路径传递 `label_cfg`，修复了单张预览与最终生成图中字号不一致的问题。

### Interactive Settings & Anti-Aliasing (Part 2) / 交互式设置与抗锯齿 (第二部分)
- **[Aesthetics] 3x Oversampling Anti-Aliasing / 3 倍过采样抗锯齿**:
  - EN: Implemented 3x oversampling with Lanczos downscaling for silk-smooth text edges.
  - CN: 实现了 3 倍过采样配合 Lanczos 缩小算法，消灭了手写文字的边缘锯齿，获得丝滑观感。
- **[Aesthetics] Smooth Bolding / 平滑加粗**:
  - EN: Replaced harsh dilation with `MaxFilter` + `GaussianBlur` to simulate organic marker ink bleeding.
  - CN: 将硬性的边缘扩张替换为 `MaxFilter` + `GaussianBlur` 组合，模拟真实墨水的微量晕染感。
- **[UI] Handright Settings Dialog / 手写体设置对话框**:
  - EN: Added scrollable and resizable dialog for real-time adjustment of word spacing, line spacing, and jitters.
  - CN: 增加了支持滚动和拉伸的设置弹窗，支持实时调节字距、行距以及各种随机抖动参数。
- **[UI] Regenerate Button / 重新生成按钮**:
  - EN: Added a "Regenerate" button to quickly refresh random handwriting variations without parameter changes.
  - CN: 增加了“重新生成”按钮，允许在不改变参数的情况下快速刷新随机的手写变化。
